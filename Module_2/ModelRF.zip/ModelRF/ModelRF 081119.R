#caret model - Random Forest, Manual Tuning Grid, 10-fold cross validation, MTRY = 5 values
#dataframe = CompleteResponses
#Y Value = Brand

### Import Data ###
library(readr)
CompleteResponses<- read.csv("~/R/XTOL/Task2/CompleteResponses2.csv")
View(CompleteResponses)
str(CompleteResponses)
head(CompleteResponses[, 1:7])

#load libraries and set seed
library(caret)
library(skimr)

#### Create Data Partition ####
# Create the training and test datasets
set.seed(100)

# Step 1: Get row numbers for the training data
trainRowNumbers <- createDataPartition(CompleteResponses$brand, p=0.75, list=FALSE)

# Step 2: Create the training  dataset
trainData <- CompleteResponses[trainRowNumbers,]

# Step 3: Create the test dataset
testData <- CompleteResponses[-trainRowNumbers,]

# Store X and Y for later use.
x = trainData[, 1:6]
y = trainData$brand

#### Pre-Processing ####
# Descriptive statistics
# Check for missing values
skimmed <- skim_to_wide(trainData)
skimmed[, c(1:5, 9:11, 13, 15:16)]

# One-Hot Encoding
# Creating dummy variables (convert a categorical variable to as many binary variables)
dummies_model <- dummyVars(brand ~ ., data = trainData)

# Create the dummy variables using predict. The Y variable (brand) will not be present in trainData_mat.
trainData_mat <- predict(dummies_model, newdata = trainData)

# Convert to dataframe
trainData <- data.frame(trainData_mat)

# See the structure of the new dataset
str(trainData)

# Data normalization
preProcess_range_model <- preProcess(trainData, method='range')
trainData <- predict(preProcess_range_model, newdata = trainData)

# Append the Y variable
trainData$brand <- y

apply(trainData[, 1:6], 2, FUN=function(x){c('min'=min(x), 'max'=max(x))})

### Visualize the importance of variables using featurePlot() ###
# Box Plot
featurePlot(x = trainData[, 1:6], y = trainData$brand, plot = "box", strip=strip.custom(par.strip.text=list(cex=.7)), scales = list(x = list(relation="free"),  y = list(relation="free")))

## Density Plot
featurePlot(x = trainData[, 1:6], y = trainData$brand, plot = "density", strip=strip.custom(par.strip.text=list(cex=.7)), scales = list(x = list(relation="free"),  y = list(relation="free")))

### Feature Engineering/Selection ###
# feature selection using recursive feature elimination (rfe)
set.seed(100)
options(warn=-1)
subsets <- c(1:5, 10, 15, 20)
ctrl <- rfeControl(functions = rfFuncs, method = "repeatedcv", repeats = 3, verbose = FALSE)
lmProfile <- rfe(x=trainData[, 1:6], y=trainData$brand, sizes = subsets, rfeControl = ctrl)
lmProfile


#### Train Control ####
#10 fold cross validation
mycontrol <- trainControl(method = "repeatedcv", number = 10, repeats = 1, classProbs = T, summaryFunction=twoClassSummary)
# Set the seed for reproducibility
set.seed(100)

#dataframe for manual tuning of mtry
rfGrid <- expand.grid(mtry=c(1,2,3,4,5))

#### Model Training ####
#train Random Forest Regression model
#note the system time wrapper. system.time()
#this is used to measure process execution time
system.time(modelrf <- train(brand ~ ., data=trainData, method='rf', trControl=mycontrol, tuneGrid=rfGrid))
fitted <- predict(modelrf)

#Model review
modelrf

# Plot the Model
plot(modelrf, main="Model Accuracies with RF")

## compute variable importance
varimprf <- varImp(modelrf)
plot(varimprf, main="Variable Importance with rf")

# Prepare the test dataset and predict
# Create one-hot encodings (dummy variables)
testData2rf <- predict(dummies_model, testData)

# Step 3: Transform the features to range between 0 and 1
testData3rf <- predict(preProcess_range_model, testData2rf)

# View
head(testData3rf[, 1:6])

#### Predict ####
# Predict on testData
predictedrf <- predict(modelrf, testData3rf)
head(predictedrf)
plot(predictedrf)

# Compute the confusion matrix
cmrf <- confusionMatrix(reference = testData$brand, data = predictedrf, mode='everything', positive='Acer')
cmrf

### Post Resample ###
postrf <- postResample(predictedrf, testData$brand)
postrf

### Predict data ###
SurveyIncompleterf <- read_csv("~/R/XTOL/Task2/SurveyIncomplete.csv")
View(SurveyIncompleterf)
SurveyIncomplete2rf <- predict(dummies_model, SurveyIncompleterf)
SurveyIncomplete3rf <- predict(preProcess_range_model, SurveyIncomplete2rf)
head(SurveyIncomplete3rf[, 1:6])
predicted2rf <- predict(modelrf, SurveyIncomplete3rf)
head(predicted2rf)
summary(predicted2rf)
plot(predicted2rf)
