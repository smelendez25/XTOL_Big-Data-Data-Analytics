#caret model - C5.0, Automatic Tuning Grid, 10-fold cross validation
#dataframe = CompleteResponses
#Y Value = Brand

### Import Data ###
library(readr)
CompleteResponses<- read.csv("~/R/XTOL/Task2/CompleteResponses2.csv")
View(CompleteResponses)
str(CompleteResponses)
head(CompleteResponses[, 1:7])

#load libraries and set seed
library(caret)
library(skimr)

#### Create Data Partition ####
# Create the training and test datasets
set.seed(100)

# Step 1: Get row numbers for the training data
trainRowNumbers <- createDataPartition(CompleteResponses$brand, p=0.75, list=FALSE)

# Step 2: Create the training  dataset
trainData <- CompleteResponses[trainRowNumbers,]

# Step 3: Create the test dataset
testData <- CompleteResponses[-trainRowNumbers,]

# Store X and Y for later use.
x = trainData[, 1:6]
y = trainData$brand

#### Pre-Processing ####
# Descriptive statistics
# Check for missing values
skimmed <- skim_to_wide(trainData)
skimmed[, c(1:5, 9:11, 13, 15:16)]

# One-Hot Encoding ###
# Creating dummy variables (convert a categorical variable to as many binary variables)
dummies_model <- dummyVars(brand ~ ., data = trainData)

# Create the dummy variables using predict. The Y variable (brand) will not be present in trainData_mat.
trainData_mat <- predict(dummies_model, newdata = trainData)

# Convert to dataframe
trainData <- data.frame(trainData_mat)

# See the structure of the new dataset
str(trainData)

# Data normalization
preProcess_range_model <- preProcess(trainData, method='range')
trainData <- predict(preProcess_range_model, newdata = trainData)

# Append the Y variable
trainData$brand <- y

apply(trainData[, 1:6], 2, FUN=function(x){c('min'=min(x), 'max'=max(x))})

### Visualize the importance of variables using featurePlot() ###
# Box Plot
featurePlot(x = trainData[, 1:6], y = trainData$brand, plot = "box", strip=strip.custom(par.strip.text=list(cex=.7)), scales = list(x = list(relation="free"),  y = list(relation="free")))

## Density Plot
featurePlot(x = trainData[, 1:6], y = trainData$brand, plot = "density", strip=strip.custom(par.strip.text=list(cex=.7)), scales = list(x = list(relation="free"),  y = list(relation="free")))

### Feature Engineering/Selection ###
# feature selection using recursive feature elimination (rfe)
set.seed(100)
options(warn=-1)
subsets <- c(1:5, 10, 15, 20)
ctrl <- rfeControl(functions = rfFuncs, method = "repeatedcv", repeats = 3, verbose = FALSE)
lmProfile <- rfe(x=trainData[, 1:6], y=trainData$brand, sizes = subsets, rfeControl = ctrl)
lmProfile

#### Train Control ####
# Set the seed for reproducibility
set.seed(100)
mycontrol <- trainControl(method = "repeatedcv", number = 10, repeats = 1)

#### Model Training ####
# Train the model using C5.0 and predict on the training data itself.
model_c5.0 = train(brand ~ ., data=trainData, method='C5.0', trControl=mycontrol, tuneLength = 7)
fitted <- predict(model_c5.0)

#Model review
model_c5.0

# Plot the Model
plot(model_c5.0, main="Model Accuracies with C5.0")

## compute variable importance
varimp_c5.0 <- varImp(model_c5.0)
plot(varimp_c5.0, main="Variable Importance with C5.0")

# Prepare the test dataset and predict
# Create one-hot encodings (dummy variables)
testData2 <- predict(dummies_model, testData)

# Step 3: Transform the features to range between 0 and 1
testData3 <- predict(preProcess_range_model, testData2)

# View
head(testData3[, 1:6])

#### Predict ####
# Predict on testData
predicted <- predict(model_c5.0, testData3)
head(predicted)
plot(predicted)

# Compute the confusion matrix
confusionMatrix(reference = testData$brand, data = predicted, mode='everything', positive='Acer')

### Post Resample ###
postResample(predicted, testData$brand)

### Predict data ###
SurveyIncomplete <- read_csv("~/R/XTOL/Task2/SurveyIncomplete.csv")
View(SurveyIncomplete)
SurveyIncomplete2 <- predict(dummies_model, SurveyIncomplete)
SurveyIncomplete3 <- predict(preProcess_range_model, SurveyIncomplete2)
head(SurveyIncomplete3[, 1:6])
predicted2 <- predict(model_c5.0, SurveyIncomplete3)
head(predicted2)
summary(predicted2)
plot(predicted2)
